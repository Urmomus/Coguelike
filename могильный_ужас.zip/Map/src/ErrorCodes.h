#ifndef ERRORCODES_H
#define ERRORCODES_H

enum ErrorCodes
{
    EMPTY_POINTER,              // вместо game_map в функцию передали NULL
    INVALID_MAP_SIZE,           // попытались использовать карту некорректного (<= 0) размера.
    

};

#endif