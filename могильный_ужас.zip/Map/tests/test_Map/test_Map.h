#ifndef TEST_MAP_H
#define TEST_MAP_H

/***********
/* @brief тестирует все функции библиотеки Map
/* @return 0, если корректно, 1, если ошибка
*/
int test_Map(char **message);

#endif